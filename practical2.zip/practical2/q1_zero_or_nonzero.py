# Write a program that reads a value of n and checks whether the number is zero or non-zero

n = int(input("Enter a number: "))

if n == 0:
    print("The number is zero")
else:
    print("The number is non-zero")
