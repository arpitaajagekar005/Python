# Find the largest number from 2 numbers, accept them from user

a = float(input("Enter first number: "))
b = float(input("Enter second number: "))

if a > b:
    print("The largest number is:", a)
elif b > a:
    print("The largest number is:", b)
else:
    print("Both numbers are equal:", a)
