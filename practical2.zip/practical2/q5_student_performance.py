# Write a program to evaluate student performance based on percentage:
# % >= 90  -> Excellent
# % >= 80  -> Very Good
# % >= 70  -> Good performance
# else     -> Poor performance

percentage = float(input("Enter percentage: "))

if percentage >= 90:
    print("Excellent")
elif percentage >= 80:
    print("Very Good")
elif percentage >= 70:
    print("Good performance")
else:
    print("Poor performance")
