# Find the largest and smallest number from three numbers, accept those numbers from user

a = float(input("Enter first number: "))
b = float(input("Enter second number: "))
c = float(input("Enter third number: "))

largest = a
if b > largest:
    largest = b
if c > largest:
    largest = c

smallest = a
if b < smallest:
    smallest = b
if c < smallest:
    smallest = c

print("Largest number is:", largest)
print("Smallest number is:", smallest)
