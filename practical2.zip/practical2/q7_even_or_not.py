# Check whether given number is even or not

n = int(input("Enter a number: "))

if n % 2 == 0:
    print("The number is even")
else:
    print("The number is not even (odd)")
