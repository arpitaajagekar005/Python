# Take input character from a user and check whether it is a vowel or consonant

ch = input("Enter a character: ")
ch = ch[0].lower()

if ch in ('a', 'e', 'i', 'o', 'u'):
    print("The character is a vowel")
elif ch.isalpha():
    print("The character is a consonant")
else:
    print("Please enter a valid alphabet character")
